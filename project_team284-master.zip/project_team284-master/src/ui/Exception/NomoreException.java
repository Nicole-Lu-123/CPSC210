//package ui.Exception;
//
//public class NomoreException extends Exception {
//
//    public NomoreException(String l){
//        super(l);
//    }
//}
