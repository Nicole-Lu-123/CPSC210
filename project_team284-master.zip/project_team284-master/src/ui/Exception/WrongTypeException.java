//package ui.Exception;
//
//public class WrongTypeException extends Exception {
//
//    public WrongTypeException(String l){
//        super(l);
//    }
//}
